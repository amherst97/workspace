package com.home.conferenceboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConferenceBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConferenceBootApplication.class, args);
	}

}
