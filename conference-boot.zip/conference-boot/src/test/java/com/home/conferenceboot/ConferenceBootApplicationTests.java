package com.home.conferenceboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConferenceBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
